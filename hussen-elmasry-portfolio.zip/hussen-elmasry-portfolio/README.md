# Hussen Elmasry — Photography Portfolio

A premium, responsive one-page photography portfolio built with plain HTML, CSS and JavaScript.

## Deploy on Render

1. Create a GitHub repository and upload all files in this folder.
2. On Render, choose **New → Static Site**.
3. Connect the GitHub repository.
4. Build command: leave empty.
5. Publish directory: `.`
6. Deploy.

`render.yaml` is included for Blueprint-based deployment.

## Customize

- Replace the Unsplash image URLs in `index.html` with your own portfolio images.
- Change the email address in the contact button.
- Add your Instagram URL in the footer.
- Update service descriptions and project names as needed.
